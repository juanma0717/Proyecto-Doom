https://grabcad.com/library/wemos-esp32-s2-mini-1
Author: Ben Cooney
