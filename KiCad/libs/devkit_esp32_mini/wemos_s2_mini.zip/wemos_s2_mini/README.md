# esp32 s2 mini wemos v1.0.0

[Símbolo](https://gitlab.com/kicad/libraries/kicad-symbols/-/merge_requests/3600)

[Footprint](https://gitlab.com/kicad/libraries/kicad-footprints/-/merge_requests/2904)
